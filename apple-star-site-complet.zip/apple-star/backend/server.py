"""
Apple Star — serveur back-end (100% bibliothèque standard Python, sans dépendance externe).

Sert :
- le site statique (frontend/)
- l'API REST (/api/...)
- l'authentification admin par cookie de session
- la base de données SQLite (produits, commandes)

Lancer :  python3 backend/server.py
Variables d'environnement :
  PORT             port d'écoute (défaut 8000)
  ADMIN_PASSWORD   mot de passe du panneau admin (défaut applestar2026 — à changer !)
"""
import datetime
import hmac
import json
import mimetypes
import os
import re
import secrets
from http import cookies
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs, quote

import database as db

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
FRONTEND_DIR = os.path.join(BASE_DIR, "..", "frontend")
ADMIN_PASSWORD = os.environ.get("ADMIN_PASSWORD", "applestar2026")
SESSION_HOURS = 12
WHATSAPP_NUMBER = "237695956018"


def utcnow():
    return datetime.datetime.utcnow()


def make_session():
    token = secrets.token_hex(24)
    expires = (utcnow() + datetime.timedelta(hours=SESSION_HOURS)).isoformat()
    conn = db.get_conn()
    conn.execute("DELETE FROM sessions WHERE expires_at < ?", (utcnow().isoformat(),))
    conn.execute("INSERT INTO sessions (token, expires_at) VALUES (?, ?)", (token, expires))
    conn.commit()
    conn.close()
    return token


def session_valid(token):
    if not token:
        return False
    conn = db.get_conn()
    row = conn.execute("SELECT expires_at FROM sessions WHERE token=?", (token,)).fetchone()
    conn.close()
    if not row:
        return False
    return datetime.datetime.fromisoformat(row["expires_at"]) > utcnow()


class Handler(BaseHTTPRequestHandler):
    server_version = "AppleStar/1.0"

    # ---------- helpers ----------
    def _send_json(self, data, status=200, set_cookie=None):
        body = json.dumps(data, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Access-Control-Allow-Origin", "*")
        if set_cookie:
            self.send_header("Set-Cookie", set_cookie)
        self.end_headers()
        self.wfile.write(body)

    def _read_json(self):
        length = int(self.headers.get("Content-Length", 0) or 0)
        if length == 0:
            return {}
        raw = self.rfile.read(length)
        try:
            return json.loads(raw.decode("utf-8"))
        except Exception:
            return {}

    def _get_cookie(self, name):
        header = self.headers.get("Cookie")
        if not header:
            return None
        jar = cookies.SimpleCookie()
        jar.load(header)
        return jar[name].value if name in jar else None

    def _is_admin(self):
        return session_valid(self._get_cookie("as_session"))

    def _require_admin(self):
        if not self._is_admin():
            self._send_json({"error": "unauthorized"}, 401)
            return False
        return True

    def _serve_static(self, path):
        if path == "/" or path == "":
            path = "/index.html"
        safe = os.path.normpath(path).lstrip("/").lstrip("\\")
        full = os.path.abspath(os.path.join(FRONTEND_DIR, safe))
        if not full.startswith(os.path.abspath(FRONTEND_DIR)):
            self.send_response(403)
            self.end_headers()
            return
        if not os.path.isfile(full):
            full = os.path.join(FRONTEND_DIR, "404.html")
            status = 404
        else:
            status = 200
        ctype, _ = mimetypes.guess_type(full)
        ctype = ctype or "application/octet-stream"
        if not os.path.isfile(full):
            self.send_response(404)
            self.end_headers()
            return
        with open(full, "rb") as f:
            body = f.read()
        self.send_response(status)
        charset = "; charset=utf-8" if ctype.startswith("text/") or "javascript" in ctype or "json" in ctype else ""
        self.send_header("Content-Type", ctype + charset)
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def log_message(self, fmt, *args):
        pass  # logs silencieux dans la console

    # ---------- CORS ----------
    def do_OPTIONS(self):
        self.send_response(204)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET,POST,PUT,PATCH,DELETE,OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.end_headers()

    # ---------- GET ----------
    def do_GET(self):
        parsed = urlparse(self.path)
        path, qs = parsed.path, parse_qs(parsed.query)

        if path == "/api/products":
            conn = db.get_conn()
            query = "SELECT * FROM products WHERE 1=1"
            params = []
            cat = qs.get("cat", [None])[0]
            if cat and cat != "all":
                query += " AND category=?"
                params.append(cat)
            if qs.get("featured", [None])[0] == "1":
                query += " AND featured=1"
            query += " ORDER BY id"
            rows = [dict(r) for r in conn.execute(query, params).fetchall()]
            conn.close()
            self._send_json({"products": rows})
            return

        m = re.match(r"^/api/products/(\d+)$", path)
        if m:
            conn = db.get_conn()
            row = conn.execute("SELECT * FROM products WHERE id=?", (m.group(1),)).fetchone()
            conn.close()
            self._send_json(dict(row)) if row else self._send_json({"error": "not found"}, 404)
            return

        if path == "/api/orders":
            if not self._require_admin():
                return
            conn = db.get_conn()
            rows = [dict(r) for r in conn.execute("SELECT * FROM orders ORDER BY id DESC").fetchall()]
            conn.close()
            self._send_json({"orders": rows})
            return

        if path == "/api/stats":
            if not self._require_admin():
                return
            conn = db.get_conn()
            stats = {
                "total_orders": conn.execute("SELECT COUNT(*) c FROM orders").fetchone()["c"],
                "new_orders": conn.execute("SELECT COUNT(*) c FROM orders WHERE status='nouveau'").fetchone()["c"],
                "total_products": conn.execute("SELECT COUNT(*) c FROM products").fetchone()["c"],
            }
            conn.close()
            self._send_json(stats)
            return

        if path == "/api/admin/me":
            self._send_json({"authenticated": self._is_admin()})
            return

        self._serve_static(path)

    # ---------- POST ----------
    def do_POST(self):
        path = urlparse(self.path).path
        data = self._read_json()

        if path == "/api/orders":
            name = (data.get("name") or "").strip()
            phone = (data.get("phone") or "").strip()
            product_name = (data.get("product_name") or "").strip()
            price = int(data.get("price") or 0)
            message = (data.get("message") or "").strip()
            if not name or not phone or not product_name:
                self._send_json({"error": "Merci de renseigner votre nom, téléphone et le produit souhaité."}, 400)
                return
            conn = db.get_conn()
            cur = conn.execute(
                "INSERT INTO orders (customer_name, phone, product_name, price, message) VALUES (?,?,?,?,?)",
                (name, phone, product_name, price, message),
            )
            conn.commit()
            order_id = cur.lastrowid
            conn.close()
            wa_text = (
                f"Bonjour Apple Star ★, je viens de passer la commande #{order_id} : {product_name}. "
                f"Mon nom : {name}. Merci de confirmer la disponibilité et la livraison."
            )
            wa_url = f"https://wa.me/{WHATSAPP_NUMBER}?text={quote(wa_text)}"
            self._send_json({"ok": True, "order_id": order_id, "whatsapp_url": wa_url}, 201)
            return

        if path == "/api/admin/login":
            password = data.get("password", "")
            if hmac.compare_digest(str(password), ADMIN_PASSWORD):
                token = make_session()
                cookie = f"as_session={token}; Path=/; HttpOnly; SameSite=Lax; Max-Age={SESSION_HOURS * 3600}"
                self._send_json({"ok": True}, 200, set_cookie=cookie)
            else:
                self._send_json({"error": "Mot de passe incorrect."}, 401)
            return

        if path == "/api/admin/logout":
            self._send_json({"ok": True}, 200, set_cookie="as_session=; Path=/; Max-Age=0")
            return

        if path == "/api/products":
            if not self._require_admin():
                return
            if not data.get("name") or not data.get("category") or not data.get("price"):
                self._send_json({"error": "Nom, catégorie et prix sont requis."}, 400)
                return
            conn = db.get_conn()
            conn.execute(
                "INSERT INTO products (name, category, specs, price, badge, color, featured, in_stock) "
                "VALUES (?,?,?,?,?,?,?,?)",
                (
                    data["name"], data["category"], data.get("specs", ""), int(data["price"]),
                    data.get("badge", ""), data.get("color", "ph-1"),
                    int(bool(data.get("featured"))), int(bool(data.get("in_stock", True))),
                ),
            )
            conn.commit()
            conn.close()
            self._send_json({"ok": True}, 201)
            return

        self._send_json({"error": "not found"}, 404)

    # ---------- PATCH ----------
    def do_PATCH(self):
        path = urlparse(self.path).path
        data = self._read_json()

        m = re.match(r"^/api/orders/(\d+)$", path)
        if m:
            if not self._require_admin():
                return
            status = data.get("status")
            if status not in ("nouveau", "confirmé", "livré", "annulé"):
                self._send_json({"error": "statut invalide"}, 400)
                return
            conn = db.get_conn()
            conn.execute("UPDATE orders SET status=? WHERE id=?", (status, m.group(1)))
            conn.commit()
            conn.close()
            self._send_json({"ok": True})
            return

        m = re.match(r"^/api/products/(\d+)$", path)
        if m:
            if not self._require_admin():
                return
            allowed = ["name", "category", "specs", "price", "badge", "color", "featured", "in_stock"]
            fields, params = [], []
            for key in allowed:
                if key in data:
                    fields.append(f"{key}=?")
                    params.append(data[key])
            if not fields:
                self._send_json({"error": "rien à mettre à jour"}, 400)
                return
            params.append(m.group(1))
            conn = db.get_conn()
            conn.execute(f"UPDATE products SET {', '.join(fields)} WHERE id=?", params)
            conn.commit()
            conn.close()
            self._send_json({"ok": True})
            return

        self._send_json({"error": "not found"}, 404)

    # ---------- DELETE ----------
    def do_DELETE(self):
        path = urlparse(self.path).path

        m = re.match(r"^/api/products/(\d+)$", path)
        if m:
            if not self._require_admin():
                return
            conn = db.get_conn()
            conn.execute("DELETE FROM products WHERE id=?", (m.group(1),))
            conn.commit()
            conn.close()
            self._send_json({"ok": True})
            return

        m = re.match(r"^/api/orders/(\d+)$", path)
        if m:
            if not self._require_admin():
                return
            conn = db.get_conn()
            conn.execute("DELETE FROM orders WHERE id=?", (m.group(1),))
            conn.commit()
            conn.close()
            self._send_json({"ok": True})
            return

        self._send_json({"error": "not found"}, 404)


def main():
    db.init_db()
    port = int(os.environ.get("PORT", 8000))
    server = ThreadingHTTPServer(("0.0.0.0", port), Handler)
    print(f"Apple Star — serveur lancé sur http://0.0.0.0:{port}")
    print(f"Panneau admin : http://0.0.0.0:{port}/admin.html (mot de passe : {ADMIN_PASSWORD})")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        server.shutdown()


if __name__ == "__main__":
    main()
