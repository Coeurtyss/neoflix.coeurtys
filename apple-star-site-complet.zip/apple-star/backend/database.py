"""
Apple Star — couche base de données (SQLite, 100% bibliothèque standard Python).
"""
import sqlite3
import os

DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "apple_star.db")


def get_conn():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    conn = get_conn()
    conn.executescript(
        """
        CREATE TABLE IF NOT EXISTS products (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            category TEXT NOT NULL,
            specs TEXT DEFAULT '',
            price INTEGER NOT NULL,
            badge TEXT DEFAULT '',
            color TEXT DEFAULT 'ph-1',
            featured INTEGER DEFAULT 0,
            in_stock INTEGER DEFAULT 1,
            created_at TEXT DEFAULT (datetime('now'))
        );

        CREATE TABLE IF NOT EXISTS orders (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            customer_name TEXT NOT NULL,
            phone TEXT NOT NULL,
            product_name TEXT NOT NULL,
            price INTEGER DEFAULT 0,
            message TEXT DEFAULT '',
            status TEXT DEFAULT 'nouveau',
            created_at TEXT DEFAULT (datetime('now'))
        );

        CREATE TABLE IF NOT EXISTS sessions (
            token TEXT PRIMARY KEY,
            created_at TEXT DEFAULT (datetime('now')),
            expires_at TEXT NOT NULL
        );
        """
    )
    conn.commit()

    count = conn.execute("SELECT COUNT(*) AS c FROM products").fetchone()["c"]
    if count == 0:
        seed_products(conn)

    conn.close()


def seed_products(conn):
    items = [
        # name, category, specs, price, badge, color, featured
        ("iPhone 16 Pro Max 256 Go", "iphone", "Puce A18 Pro, écran 6.7\", triple capteur 48MP", 850000, "Neuf", "ph-1", 0),
        ("iPhone 15 128 Go", "iphone", "Puce A16, écran 6.1\", double capteur photo", 520000, "Neuf", "ph-1", 1),
        ("iPhone 14 128 Go", "iphone", "Puce A15, écran Super Retina XDR", 420000, "Neuf", "ph-1", 0),
        ("iPhone 13 128 Go (Occasion UK)", "iphone", "Batterie ≥85%, état impeccable", 290000, "Occasion", "ph-1", 0),
        ("iPhone 12 64 Go (Occasion)", "iphone", "Idéal premier iPhone, état vérifié", 210000, "Occasion", "ph-1", 0),

        ("Samsung Galaxy S24 256 Go", "samsung", "AMOLED 6.2\", 5G, charge rapide", 480000, "Neuf", "ph-2", 1),
        ("Samsung Galaxy A55 128 Go", "samsung", "Caméra 50MP, batterie longue durée", 220000, "Neuf", "ph-2", 0),
        ("Samsung Galaxy A15 128 Go", "samsung", "Grand écran, design soigné", 110000, "Neuf", "ph-2", 0),
        ("Samsung Galaxy A05 64 Go", "samsung", "Entrée de gamme fiable", 75000, "Neuf", "ph-2", 0),

        ("Tecno Camon 30 Pro", "local", "128 Go, caméra 50MP, écran AMOLED", 165000, "Populaire", "ph-3", 1),
        ("Tecno Spark 20", "local", "Léger, rapide, bonne autonomie", 95000, "Neuf", "ph-3", 0),
        ("Infinix Note 40", "local", "Charge ultra-rapide, grand écran", 145000, "Neuf", "ph-5", 0),
        ("Infinix Hot 50", "local", "Excellent rapport qualité-prix", 80000, "Neuf", "ph-5", 0),
        ("Infinix Smart 9", "local", "Idéal pour un usage simple", 55000, "Neuf", "ph-5", 0),

        ("Écouteurs sans fil Pro", "accessoires", "Bluetooth 5.3, réduction de bruit", 15000, "Tendance", "ph-4", 1),
        ("Chargeur rapide 33W", "accessoires", "Compatible USB-C, charge ultra-rapide", 8000, "", "ph-6", 0),
        ("Power bank 20000mAh", "accessoires", "Double sortie USB, charge 2 appareils", 18000, "", "ph-6", 0),
        ("Coque de protection", "accessoires", "Anti-choc, plusieurs coloris", 3500, "", "ph-6", 0),
        ("Câble USB-C / Lightning renforcé", "accessoires", "Résistant, charge rapide", 4000, "", "ph-6", 0),
    ]
    conn.executemany(
        "INSERT INTO products (name, category, specs, price, badge, color, featured) "
        "VALUES (?, ?, ?, ?, ?, ?, ?)",
        items,
    )
    conn.commit()
