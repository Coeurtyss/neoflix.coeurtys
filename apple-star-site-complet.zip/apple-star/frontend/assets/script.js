// =========================================================
// APPLE STAR — script.js (front-end relié à l'API back-end)
// =========================================================
const API = "/api";

function initNav() {
  const burger = document.querySelector(".burger");
  if (!burger) return;
  burger.addEventListener("click", () => document.body.classList.toggle("menu-open"));
  document.querySelectorAll(".mobile-panel a").forEach((a) => {
    a.addEventListener("click", () => document.body.classList.remove("menu-open"));
  });
}

// Ambient "Apple Star" background marquee — present in every section.
function initAmbientMarquees() {
  document.querySelectorAll(".marquee-bg").forEach((box) => {
    box.innerHTML = "";
    for (let i = 0; i < 3; i++) {
      const row = document.createElement("div");
      row.className = "row";
      let chunk = "";
      for (let j = 0; j < 8; j++) chunk += `<span>Apple Star <i>★</i></span>`;
      row.innerHTML = chunk + chunk; // duplicated once -> seamless loop with translateX(-50%)
      box.appendChild(row);
    }
  });
}

function initTicker() {
  document.querySelectorAll(".ticker-track").forEach((track) => {
    track.innerHTML = track.innerHTML + track.innerHTML;
  });
}

function formatPrice(n) {
  return new Intl.NumberFormat("fr-FR").format(n).replace(/\u202f|\u00a0/g, " ") + " FCFA";
}

// ---------- Catalogue rendering ----------
function productCardHTML(p) {
  const isAccessory = p.category === "accessoires";
  const shape = isAccessory
    ? `style="background:linear-gradient(160deg,#F4D27A,#B5862A);width:60px;height:120px;border-radius:50px"`
    : "";
  return `
    <div class="product-card" data-cat="${p.category}" data-id="${p.id}">
      <div class="product-media ${p.color || "ph-1"}">
        ${p.badge ? `<span class="badge">${p.badge}</span>` : ""}
        <div class="mini-phone" ${shape}></div>
      </div>
      <div class="product-body">
        <h3>${p.name}</h3>
        <p class="specs">${p.specs || ""}</p>
        <div class="product-foot">
          <span class="price">${formatPrice(p.price)}<small>prix boutique</small></span>
          <button class="btn btn-coral btn-sm order-btn" data-name="${p.name.replace(/"/g, "&quot;")}" data-price="${p.price}">Commander</button>
        </div>
      </div>
    </div>`;
}

async function fetchProducts(params = {}) {
  const qs = new URLSearchParams(params).toString();
  const res = await fetch(`${API}/products${qs ? "?" + qs : ""}`);
  if (!res.ok) throw new Error("Impossible de charger le catalogue.");
  const data = await res.json();
  return data.products || [];
}

async function loadFeatured() {
  const grid = document.querySelector("#featured-grid");
  if (!grid) return;
  try {
    const products = await fetchProducts({ featured: "1" });
    grid.innerHTML = products.map(productCardHTML).join("") || "<p>Aucun produit en vedette pour le moment.</p>";
    bindOrderButtons(grid);
  } catch (e) {
    grid.innerHTML = `<p>Le catalogue est momentanément indisponible. Réessayez dans un instant.</p>`;
  }
}

async function loadCatalogue() {
  const grid = document.querySelector("#catalogue-grid");
  if (!grid) return;
  const params = new URLSearchParams(window.location.search);
  const initialCat = params.get("cat") || "all";

  const render = async (cat) => {
    grid.innerHTML = `<p>Chargement du catalogue…</p>`;
    try {
      const products = await fetchProducts(cat === "all" ? {} : { cat });
      grid.innerHTML = products.map(productCardHTML).join("") ||
        `<p>Aucun produit dans cette catégorie pour le moment.</p>`;
      bindOrderButtons(grid);
    } catch (e) {
      grid.innerHTML = `<p>Le catalogue est momentanément indisponible. Réessayez dans un instant.</p>`;
    }
  };

  document.querySelectorAll(".filter-btn").forEach((btn) => {
    btn.classList.toggle("active", btn.dataset.filter === initialCat);
    btn.addEventListener("click", () => {
      document.querySelectorAll(".filter-btn").forEach((b) => b.classList.remove("active"));
      btn.classList.add("active");
      render(btn.dataset.filter);
    });
  });

  render(initialCat);
}

// ---------- Commande (enregistrée côté serveur, puis ouverte sur WhatsApp) ----------
async function submitOrder({ name, phone, product_name, price, message }) {
  const res = await fetch(`${API}/orders`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ name, phone, product_name, price, message }),
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || "Une erreur est survenue.");
  return data;
}

function openQuickOrderModal(name, price) {
  let modal = document.querySelector("#quick-order-modal");
  if (!modal) {
    modal = document.createElement("div");
    modal.id = "quick-order-modal";
    modal.className = "qo-overlay";
    modal.innerHTML = `
      <div class="qo-box">
        <button class="qo-close" aria-label="Fermer">✕</button>
        <p class="eyebrow">Commande rapide</p>
        <h3 id="qo-title">Produit</h3>
        <p id="qo-price" class="price" style="font-size:18px;color:var(--navy)"></p>
        <form id="qo-form">
          <div class="field"><label>Votre nom</label><input id="qo-name" required placeholder="Ex : Marie Ngo"></div>
          <div class="field"><label>Numéro de téléphone</label><input id="qo-phone" required placeholder="Ex : 6XX XX XX XX"></div>
          <div class="field"><label>Message (optionnel)</label><textarea id="qo-message" placeholder="Couleur, quartier de livraison…"></textarea></div>
          <button type="submit" class="btn btn-coral btn-block">Envoyer la commande</button>
          <p class="form-note"></p>
        </form>
      </div>`;
    document.body.appendChild(modal);
    modal.querySelector(".qo-close").addEventListener("click", () => modal.classList.remove("show"));
    modal.addEventListener("click", (e) => { if (e.target === modal) modal.classList.remove("show"); });
  }
  modal.querySelector("#qo-title").textContent = name;
  modal.querySelector("#qo-price").textContent = formatPrice(Number(price));
  const form = modal.querySelector("#qo-form");
  const note = form.querySelector(".form-note");
  note.textContent = "";
  form.onsubmit = async (e) => {
    e.preventDefault();
    const submitBtn = form.querySelector("button[type=submit]");
    submitBtn.disabled = true;
    submitBtn.textContent = "Envoi…";
    try {
      const result = await submitOrder({
        name: form.querySelector("#qo-name").value.trim(),
        phone: form.querySelector("#qo-phone").value.trim(),
        product_name: name,
        price: Number(price),
        message: form.querySelector("#qo-message").value.trim(),
      });
      note.style.color = "#15813F";
      note.textContent = `Commande #${result.order_id} enregistrée ! Ouverture de WhatsApp pour confirmer…`;
      window.open(result.whatsapp_url, "_blank");
      setTimeout(() => modal.classList.remove("show"), 1200);
    } catch (err) {
      note.style.color = "#E0502F";
      note.textContent = err.message;
    } finally {
      submitBtn.disabled = false;
      submitBtn.textContent = "Envoyer la commande";
    }
  };
  modal.classList.add("show");
  modal.querySelector("#qo-name").focus();
}

function bindOrderButtons(scope = document) {
  scope.querySelectorAll(".order-btn").forEach((btn) => {
    btn.addEventListener("click", () => openQuickOrderModal(btn.dataset.name, btn.dataset.price));
  });
}

// ---------- Formulaire de contact ----------
function initContactForm() {
  const form = document.querySelector("#contact-form");
  if (!form) return;
  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    const note = form.querySelector(".form-note");
    const submitBtn = form.querySelector("button[type=submit]");
    const payload = {
      name: form.querySelector("#cf-name").value.trim(),
      phone: form.querySelector("#cf-phone").value.trim(),
      product_name: form.querySelector("#cf-model").value || "Demande d'information",
      price: 0,
      message: form.querySelector("#cf-message").value.trim(),
    };
    submitBtn.disabled = true;
    submitBtn.textContent = "Envoi…";
    try {
      const result = await submitOrder(payload);
      note.style.color = "#15813F";
      note.textContent = `Demande #${result.order_id} enregistrée. Ouverture de WhatsApp pour finaliser…`;
      window.open(result.whatsapp_url, "_blank");
      form.reset();
    } catch (err) {
      note.style.color = "#E0502F";
      note.textContent = err.message;
    } finally {
      submitBtn.disabled = false;
      submitBtn.textContent = "Envoyer la demande";
    }
  });
}

document.addEventListener("DOMContentLoaded", () => {
  initNav();
  initAmbientMarquees();
  initTicker();
  loadFeatured();
  loadCatalogue();
  initContactForm();
});
