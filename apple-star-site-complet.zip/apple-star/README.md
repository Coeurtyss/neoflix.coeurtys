# Apple Star — Site complet (front-end + back-end)

Boutique de téléphones à Bertoua, Cameroun. Catalogue dynamique, commande en ligne enregistrée en base de données, et panneau d'administration — tout en plus de la commande directe sur WhatsApp.

## Ce que contient ce projet

```
apple-star/
├── backend/
│   ├── server.py        → serveur + API (Python, aucune dépendance à installer)
│   └── database.py       → base de données SQLite + catalogue de départ
├── frontend/
│   ├── index.html         → accueil
│   ├── catalogue.html      → catalogue complet avec filtres
│   ├── apropos.html        → à propos / horaires
│   ├── contact.html        → formulaire de contact + WhatsApp
│   ├── admin.html          → panneau d'administration (privé)
│   └── assets/             → CSS, JS
└── README.md
```

## Comment ça marche

- Le **catalogue** (produits + prix) est stocké dans une vraie base de données (`apple_star.db`, créée automatiquement au premier lancement).
- Quand un client clique sur **« Commander »**, la commande est enregistrée dans la base **et** WhatsApp s'ouvre automatiquement pour confirmer avec vous — vous gardez votre façon de discuter avec les clients, mais vous avez maintenant un historique de toutes les commandes.
- Le **panneau admin** (`/admin.html`) vous permet, sans toucher au code :
  - de voir toutes les commandes et changer leur statut (nouveau / confirmé / livré / annulé),
  - d'ajouter, modifier ou supprimer un téléphone du catalogue (le site se met à jour immédiatement).

Il n'y a **pas de paiement en ligne intégré** (carte bancaire, API Mobile Money) — ce n'est pas raisonnable à mettre en place sans contrat avec MTN/Orange. Le paiement reste géré comme aujourd'hui : Mobile Money ou espèces à la confirmation/livraison.

## Lancer le site sur votre ordinateur

Il faut juste Python (déjà installé sur la plupart des ordinateurs, gratuit ici : https://python.org).

```bash
cd apple-star/backend
python3 server.py
```

Puis ouvrez dans votre navigateur :
- Site : http://localhost:8000
- Admin : http://localhost:8000/admin.html — mot de passe par défaut : `applestar2026`

**Important : changez ce mot de passe avant de mettre le site en ligne** (voir ci-dessous).

## Changer le mot de passe admin

Définissez la variable d'environnement `ADMIN_PASSWORD` avant de lancer le serveur :

```bash
ADMIN_PASSWORD="votre-nouveau-mot-de-passe" python3 server.py
```

## Mettre le site en ligne (hébergement)

Ce site a un vrai back-end : **GitHub Pages ne suffit plus** (il n'héberge que des fichiers statiques). Il faut un hébergeur qui exécute du code Python. Options simples et gratuites pour démarrer :

### Option recommandée : Render.com
1. Créez un compte sur https://render.com et un nouveau dépôt GitHub avec ce projet.
2. Sur Render : « New Web Service » → connectez le dépôt.
3. Build command : *(laisser vide)*
4. Start command : `python3 backend/server.py`
5. Dans « Environment », ajoutez la variable `ADMIN_PASSWORD` avec votre mot de passe.
6. Render vous donne une adresse du type `https://apple-star.onrender.com`.

### Option alternative : Railway.app ou PythonAnywhere
Le principe est le même : déployer le dossier, lancer `python3 backend/server.py`, définir `ADMIN_PASSWORD`.

### Nom de domaine personnalisé
Une fois en ligne sur Render/Railway, vous pouvez relier un domaine acheté sur Namecheap ou Hostinger (ex. `appleStar.shop`) depuis les réglages du service.

## Sauvegarder vos données

Toutes les commandes et le catalogue sont dans le fichier `backend/apple_star.db`. Pensez à le télécharger régulièrement si votre hébergeur ne garde pas les fichiers de façon permanente (sur certains hébergeurs gratuits, le disque peut être réinitialisé — demandez un disque persistant si possible).

## Personnaliser

- **Catalogue de départ** : modifiable dans `backend/database.py` (fonction `seed_products`) avant le premier lancement, ou directement depuis le panneau admin après.
- **Numéro WhatsApp** : actuellement `+237 695 95 60 18`, modifiable dans `backend/server.py` (`WHATSAPP_NUMBER`) et dans les liens des pages `frontend/*.html`.
- **Adresse exacte de la boutique** : à ajouter dans `frontend/contact.html` (section carte) pour activer une vraie carte Google Maps.
